# Consultorio Dental Santa Maria

Pagina web lista para GitHub Pages.

## Como subir a GitHub
1. Crea un repositorio nuevo en github.com (nombre: consultorio-dental)
2. Arrastra TODO el contenido de esta carpeta (los 6 html + carpeta imagenes) al repositorio
3. Ve a Settings > Pages > Source: Deploy from a branch > Branch: main / (root) > Save
4. En 1-2 minutos tu pagina estara en https://tu-usuario.github.io/consultorio-dental/

Estructura:
- index.html
- servicios.html
- horarios.html
- promociones.html
- ayuda.html
- otros.html
- imagenes/ (8 imagenes)

No se modifico ningun archivo HTML original.
